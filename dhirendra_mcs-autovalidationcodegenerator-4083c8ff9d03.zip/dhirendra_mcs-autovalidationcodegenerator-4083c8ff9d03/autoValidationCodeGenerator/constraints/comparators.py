from autoValidationCodeGenerator.supported_frameworks import TargetFramework
from jinja2 import Environment, FileSystemLoader
from spacy.tokens import span

from spacy.attrs import LOWER, POS, ENT_TYPE, IS_ALPHA, LIKE_NUM, IS_PUNCT


class Comparators :

    def __init__ (self) :
        self._rules = [
            [ {"POS": {"IN": ["NOUN", "PROPN"]}},
              {"ORTH": {"IN": [ ":", "=", "<", ">", "!" ]}, "OP": "+"},
              {"POS": {"IN": ["NOUN", "PROPN"]}} ],
        ]
        self._template_file = "check_comparator.txt"

    @property
    def rules (self) :
        return self._rules

    def generate_code (self, field_name: str, field_desc: str, match_span: span,target_framework: TargetFramework) -> str :
        lname_val = None
        rname_val = None
        isequal = isgreaterThan = islessThan = isnegative = False

        for token in match_span:
            if (lname_val == None) and (token.pos_ in ["NOUN", "PROPN"]):
                lname_val = token.lemma_
            elif (token.pos_ in ["PROPN","NOUN"]) :
                rname_val = token.lemma_
            elif token.text == "=" :
                isequal = True
            elif token.text == ">":
                isgreaterThan = True
            elif token.text == "<" :
                islessThan = True
            elif token.text == "!" :
                isnegative = True

        if lname_val.lower() == "value":
            lname_val = field_name


        if (isequal):
            if (isgreaterThan):
                op_val = ">="
                op_desc_val = "gte"
            elif (islessThan):
                op_val = "<="
                op_desc_val = "lte"
            elif (isnegative):
                op_val = "!="
                op_desc_val = "neq"
            else:
                op_val = "=="
                op_desc_val = "eq"
        else:
            if (isgreaterThan):
                op_val = ">"
                op_desc_val = "gt"
            else:
                op_val = "<"
                op_desc_val = "lt"


        file_loader = FileSystemLoader('../templates/' + target_framework.name.lower())
        env = Environment(loader = file_loader)
        template = env.get_template(self._template_file)

        return template.render(lname = lname_val, rname = rname_val, op = op_val, op_desc = op_desc_val)

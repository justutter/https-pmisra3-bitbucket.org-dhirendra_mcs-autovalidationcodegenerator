from autoValidationCodeGenerator.supported_frameworks import TargetFramework
from jinja2 import Environment, FileSystemLoader
from spacy.tokens import span

from spacy.attrs import LOWER, POS, ENT_TYPE, IS_ALPHA, LIKE_NUM, IS_PUNCT


class AllEqualTo :

    def __init__ (self) :
        self._rules = [
            [ {"POS": {"IN": ["NOUN", "PROPN"]}},
              {"ORTH": {"IN": [ ":", "=" ]}, "OP": "+"},
              {"LIKE_NUM": True} ],
            [ {"POS": {"IN": [ "NOUN", "PROPN" ]}},
              {"ORTH": {"IN": [ ":", "=" ]}, "OP": "+"},
              {"ORTH" : {"IN" : [ "'", "\"" ]}, "OP" : "+"},
              {"POS": {"IN": ["NOUN", "PROPN", "NUM"]}},
              {"ORTH": {"IN": ["'", "\""]}, "OP": "*"} ],
            [ {"POS": {"IN": ["NOUN", "PROPN"]}},
              {"LEMMA": {"IN": ["be", "equal", "to", "have", "must"]}, "OP": "+" },
              {"LIKE_NUM": True} ],
            [ {"POS" : {"IN" : [ "NOUN", "PROPN" ]}},
              {"LEMMA" : {"IN" : [ "be", "equal", "to", "have", "must" ]}, "OP" : "+"},
              {"ORTH": {"IN": ["'", "\""]}},
              {"POS": {"IN": ["NOUN", "PROPN", "NUM"]}},
              {"ORTH": {"IN": ["'", "\""]}, "OP": "?"}]
        ]
        self._template_file = "check_all_equal_of.txt"

    @property
    def rules (self) :
        return self._rules

    def generate_code (self, field_name: str, field_desc: str, match_span: span,target_framework: TargetFramework) -> str :

        fname_value = None
        litteral_val = None

        for token in match_span:
            if (fname_value == None) and (token.pos_ in ["NOUN", "PROPN"]):
                fname_value = token.lemma_
            elif (token.pos_ in ["PROPN","NOUN"]) :
                litteral_val = "'" + token.text + "'"
            elif token.pos_ == "NUM" :
                litteral_val = token.text

        if fname_value.lower() == "value":
            fname_value = field_name

        file_loader = FileSystemLoader('../templates/' + target_framework.name.lower())
        env = Environment(loader = file_loader)
        template = env.get_template(self._template_file)
        return template.render(fname = fname_value, literal_value = litteral_val)

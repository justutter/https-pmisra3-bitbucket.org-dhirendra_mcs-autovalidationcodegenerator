import pandas as pd
import pytest
import rpy2


from autoValidationCodeGenerator.orchestrator import TargetFramework
from autoValidationCodeGenerator.orchestrator import ValidationCodeGenerator
import rpy2.robjects as robjects
import rpy2.robjects as ro
from rpy2.robjects import pandas2ri
from rpy2.robjects.conversion import localconverter


@pytest.mark.parametrize(
    'field_name, field_desc',
    [
        ("price", "price must be 5"),
        ("price", "price are 5"),
        ("price", "price is equal to 5"),
        ("price", "5"),
        ("price", "price := 5"),
        ("price", "price == 5"),
        ("price", "value : 5")
     ],
    ids = ["Must Be Variation", "Is/Are Variation", "Text Variation", "Only Value Present", "Symbol Variation 1", "Symbol Variation 2", "Symbol Variation 3"]
)
def test_generate_code_allequalto_num(field_name, field_desc):
    test_class_instance = ValidationCodeGenerator(TargetFramework.R)
    expected_result = "check_all_equal_of_price <- function ( dataframe ) {\n"  \
                      "    all( ( dataframe$price == 5 ) == TRUE )\n" \
                      "}";

    result_code = test_class_instance.generate_code(field_name, field_desc)

    assert result_code.strip() == expected_result.strip()


@pytest.mark.skipif(rpy2.__version__ < '3.2.4', reason = "Works only with versions higher than 3.2.4 ")
@pytest.mark.parametrize(
    'field_name, field_desc, valid_data',
    [
        ("price", "price must be 5", {'price': [5, 5, 5]} ),
        ("price", "price are 6", {'price': [6, 6]}),
        ("price", "price is equal to 7", {'price': [7]}),
        ("price", "8", {'price': [8, 8, 8]}),
        ("price", "price := 5", {'price': [5, 5, 5]}),
        ("price", "price == 5", {'price': [5, 5, 5]}),
        ("price", "value : 5", {'price': [5, 5, 5]})
     ],
    ids = ["Must Be Variation", "Is/Are Variation", "Text Variation", "Only Value Present", "Symbol Variation 1", "Symbol Variation 2", "Symbol Variation 3"]
)
def test_generated_code_returns_true_on_valid_data(field_name, field_desc, valid_data):
    test_class_instance = ValidationCodeGenerator(TargetFramework.R)

    valid_data = pd.DataFrame(valid_data)
    with localconverter(ro.default_converter + pandas2ri.converter) :
        valid_data = ro.conversion.py2rpy(valid_data)

    result_code = test_class_instance.generate_code(field_name, field_desc)
    result_rfunc = robjects.r(result_code)

    assert result_rfunc(valid_data)[0]


@pytest.mark.skipif(rpy2.__version__ < '3.2.4', reason = "Works only with versions higher than 3.2.4 ")
@pytest.mark.parametrize(
    'field_name, field_desc, invalid_data',
    [
        ("price", "price must be 5", {'price': [6, 5, 5]} ),
        ("price", "price are 6", {'price': [7, 6]}),
        ("price", "price is equal to 7", {'price': [0]}),
        ("price", "8", {'price': [8, 9, 8]}),
        ("price", "price := 5", {'price': [5, 7, 5]}),
        ("price", "price == 5", {'price': [5, 5, 8]}),
        ("price", "value : 5", {'price': [5, 9, 5]})
     ],
    ids = ["Must Be Variation", "Is/Are Variation", "Text Variation", "Only Value Present", "Symbol Variation 1", "Symbol Variation 2", "Symbol Variation 3"]
)
def test_generated_code_returns_false_on_invalid_data(field_name, field_desc, invalid_data):
    test_class_instance = ValidationCodeGenerator(TargetFramework.R)

    invalid_data = pd.DataFrame(invalid_data)
    with localconverter(ro.default_converter + pandas2ri.converter) :
        invalid_data = ro.conversion.py2rpy(invalid_data)

    result_code = test_class_instance.generate_code(field_name, field_desc)
    result_rfunc = robjects.r(result_code)

    assert result_rfunc(invalid_data)[0] != True

@pytest.mark.parametrize(
    'field_name, field_desc',
    [
        ("price", "price must be 'abc'"),
        ("price", "price are 'abc'"),
        ("price", "price is equal to 'abc"),
        ("price", "'abc'"),
        ("price", "price := 'abc'"),
        ("price", "price == 'abc'"),
        ("price", "value : 'abc'")
     ],
    ids = ["Must Be Variation", "Is/Are Variation", "Text Variation", "Only Value Present", "Symbol Variation 1", "Symbol Variation 2", "Symbol Variation 3"]
)
def test_generate_code_allequalto_text(field_name, field_desc):
    test_class_instance = ValidationCodeGenerator(TargetFramework.R)
    expected_result = "check_all_equal_of_price <- function ( dataframe ) {\n"  \
                      "    all( ( dataframe$price == 'abc' ) == TRUE )\n" \
                      "}";

    result_code = test_class_instance.generate_code(field_name, field_desc)

    assert result_code.strip() == expected_result.strip()
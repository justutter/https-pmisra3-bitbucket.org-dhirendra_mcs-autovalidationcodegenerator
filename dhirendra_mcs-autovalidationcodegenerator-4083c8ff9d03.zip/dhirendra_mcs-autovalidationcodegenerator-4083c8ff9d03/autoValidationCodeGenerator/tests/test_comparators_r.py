
import pytest


from autoValidationCodeGenerator.orchestrator import TargetFramework
from autoValidationCodeGenerator.orchestrator import ValidationCodeGenerator


@pytest.mark.parametrize(
    'field_name, field_desc',
    [
        ("mileage", "mileage >= gears")
     ],
    ids = ["Symbol"]
)
def test_generate_code_greater_than_equals(field_name, field_desc):
    test_class_instance = ValidationCodeGenerator(TargetFramework.R)
    expected_result = "check_mileage_gte_gear <- function ( dataframe ) {\n"  \
                      "    all( ( dataframe['mileage'] >= dataframe['gear'] ) == TRUE )\n" \
                      "}";

    result_code = test_class_instance.generate_code(field_name, field_desc)

    assert result_code.strip() == expected_result.strip()


@pytest.mark.parametrize(
    'field_name, field_desc',
    [
        ("mileage", "mileage <= gears")
     ],
    ids = ["Symbol"]
)
def test_generate_code_less_than_equals(field_name, field_desc):
    test_class_instance = ValidationCodeGenerator(TargetFramework.R)
    expected_result = "check_mileage_lte_gear <- function ( dataframe ) {\n"  \
                      "    all( ( dataframe['mileage'] <= dataframe['gear'] ) == TRUE )\n" \
                      "}";

    result_code = test_class_instance.generate_code(field_name, field_desc)

    assert result_code.strip() == expected_result.strip()


@pytest.mark.parametrize(
    'field_name, field_desc',
    [
        ("mileage", "mileage == gears")
     ],
    ids = ["Symbol"]
)
def test_generate_code_equals(field_name, field_desc):
    test_class_instance = ValidationCodeGenerator(TargetFramework.R)
    expected_result = "check_mileage_eq_gear <- function ( dataframe ) {\n"  \
                      "    all( ( dataframe['mileage'] == dataframe['gear'] ) == TRUE )\n" \
                      "}";

    result_code = test_class_instance.generate_code(field_name, field_desc)

    assert result_code.strip() == expected_result.strip()

@pytest.mark.parametrize(
    'field_name, field_desc',
    [
        ("mileage", "mileage != gears")
     ],
    ids = ["Symbol"]
)
def test_generate_code_not_equals(field_name, field_desc):
    test_class_instance = ValidationCodeGenerator(TargetFramework.R)
    expected_result = "check_mileage_neq_gear <- function ( dataframe ) {\n"  \
                      "    all( ( dataframe['mileage'] != dataframe['gear'] ) == TRUE )\n" \
                      "}";

    result_code = test_class_instance.generate_code(field_name, field_desc)

    assert result_code.strip() == expected_result.strip()

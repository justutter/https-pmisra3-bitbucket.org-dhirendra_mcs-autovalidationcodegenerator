import pandas as pd
import pytest


from autoValidationCodeGenerator.orchestrator import TargetFramework
from autoValidationCodeGenerator.orchestrator import ValidationCodeGenerator
from types import FunctionType


@pytest.mark.parametrize(
    'field_name, field_desc',
    [
        ("price", "price must be 5"),
        ("price", "price are 5"),
        ("price", "price is equal to 5"),
        ("price", "5"),
        ("price", "price := 5"),
        ("price", "price == 5"),
        ("price", "value : 5")
     ],
    ids = ["Must Be Variation", "Is/Are Variation", "Text Variation", "Only Value Present", "Symbol Variation 1", "Symbol Variation 2", "Symbol Variation 3"]
)
def test_generate_code_allequalto_num(field_name, field_desc):
    test_class_instance = ValidationCodeGenerator(TargetFramework.PANDAS)
    expected_result = "def check_all_equal_of_price ( dataframe ) :\n"  \
                      "   return (dataframe['price'] == 5).all()";

    result_code = test_class_instance.generate_code(field_name, field_desc)

    assert result_code.strip() == expected_result.strip()


@pytest.mark.parametrize(
    'field_name, field_desc, valid_data',
    [
        ("price", "price must be 5", {'price': [5, 5, 5]} ),
        ("price", "price are 6", {'price': [6, 6]}),
        ("price", "price is equal to 7", {'price': [7]}),
        ("price", "8", {'price': [8, 8, 8]}),
        ("price", "price := 5", {'price': [5, 5, 5]}),
        ("price", "price == 5", {'price': [5, 5, 5]}),
        ("price", "value : 5", {'price': [5, 5, 5]})
     ],
    ids = ["Must Be Variation", "Is/Are Variation", "Text Variation", "Only Value Present", "Symbol Variation 1", "Symbol Variation 2", "Symbol Variation 3"]
)
def test_generated_code_returns_true_on_valid_data(field_name, field_desc, valid_data):
    test_class_instance = ValidationCodeGenerator(TargetFramework.PANDAS)

    result_code = test_class_instance.generate_code(field_name, field_desc)

    compiled_f_code = compile(result_code, "<string>", "exec")
    validate_func = FunctionType(compiled_f_code.co_consts[ 0 ], globals(), "validate")
    assert validate_func(pd.DataFrame(valid_data))


@pytest.mark.parametrize(
    'field_name, field_desc, invalid_data',
    [
        ("price", "price must be 5", {'price': [6, 5, 5]} ),
        ("price", "price are 6", {'price': [7, 6]}),
        ("price", "price is equal to 7", {'price': [0]}),
        ("price", "8", {'price': [8, 9, 8]}),
        ("price", "price := 5", {'price': [5, 7, 5]}),
        ("price", "price == 5", {'price': [5, 5, 8]}),
        ("price", "value : 5", {'price': [5, 9, 5]})
     ],
    ids = ["Must Be Variation", "Is/Are Variation", "Text Variation", "Only Value Present", "Symbol Variation 1", "Symbol Variation 2", "Symbol Variation 3"]
)
def test_generated_code_returns_false_on_invalid_data(field_name, field_desc, invalid_data):
    test_class_instance = ValidationCodeGenerator(TargetFramework.PANDAS)

    result_code = test_class_instance.generate_code(field_name, field_desc)

    compiled_f_code = compile(result_code, "<string>", "exec")
    validate_func = FunctionType(compiled_f_code.co_consts[ 0 ], globals(), "validate")
    assert validate_func(pd.DataFrame(invalid_data)) != True


@pytest.mark.parametrize(
    'field_name, field_desc',
    [
        ("price", "price must be 'abc'"),
        ("price", "price are 'abc'"),
        ("price", "price is equal to 'abc"),
        ("price", "'abc'"),
        ("price", "price := 'abc'"),
        ("price", "price == 'abc'"),
        ("price", "value : 'abc'")
     ],
    ids = ["Must Be Variation", "Is/Are Variation", "Text Variation", "Only Value Present", "Symbol Variation 1", "Symbol Variation 2", "Symbol Variation 3"]
)
def test_generate_code_allequalto_text(field_name, field_desc):
    test_class_instance = ValidationCodeGenerator(TargetFramework.PANDAS)
    expected_result = "def check_all_equal_of_price ( dataframe ) :\n"  \
                      "   return (dataframe['price'] == 'abc').all()";

    result_code = test_class_instance.generate_code(field_name, field_desc)

    assert result_code.strip() == expected_result.strip()

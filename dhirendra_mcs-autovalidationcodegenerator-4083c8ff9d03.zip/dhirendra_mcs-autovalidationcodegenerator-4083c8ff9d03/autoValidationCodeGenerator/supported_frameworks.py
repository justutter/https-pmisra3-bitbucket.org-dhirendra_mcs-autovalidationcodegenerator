from enum import Enum


class TargetFramework(Enum):
    PANDAS = 1
    R = 2

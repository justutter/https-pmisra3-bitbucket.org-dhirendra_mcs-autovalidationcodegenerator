import spacy
import re

from autoValidationCodeGenerator.supported_frameworks import TargetFramework
from autoValidationCodeGenerator.constraints.allequalto import AllEqualTo
from autoValidationCodeGenerator.constraints.comparators import Comparators

from spacy.matcher import Matcher


class ValidationCodeGenerator :
    _nlp = None
    _targetFramework = None
    _pattern_registry = None

    def __init__ (self, target_framework: TargetFramework) :
        self._targetFramework = target_framework
        self._nlp = spacy.load("en_core_web_sm")
        self._pattern_registry = {
            "allEqualTo": AllEqualTo(),
            "comparator": Comparators()
        }

    def __del__ (self) :
        self._nlp = None
        self._targetFramework = None

    def generate_code (self, field_name: str, field_desc: str) -> str :

        # Replace multiple spaces with single space in desc
        field_desc = re.sub('\s+', ' ', field_desc).strip()

        # If there is only 1 word, we do data augmentation
        if len(field_desc.split()) == 1 :
            field_desc = field_name + " is " + field_desc

        # instantiate the matcher
        matcher = Matcher(self._nlp.vocab)

        # register all patterns with matcher
        for key, value in self._pattern_registry.items():
            matcher.add(key, None, *value.rules)

        # find matches
        doc = self._nlp(field_desc)
        matches = matcher(doc)

        # for every match call the corresponding rules code generator
        for match_id, start, end in matches :
            string_id = self._nlp.vocab.strings[ match_id ]
            match_span = doc[ start :end ]
            print(match_id, string_id, start, end, match_span.text)
            return self._pattern_registry.get(string_id).generate_code(field_name, field_desc, match_span, self._targetFramework)

        return ""

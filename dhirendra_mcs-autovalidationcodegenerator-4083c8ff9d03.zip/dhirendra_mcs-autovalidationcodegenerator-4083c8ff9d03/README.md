# Auto Validation Code Generator

### 1. Overview  
Data is the fuel powering AI and digital transformation and thus data quality and controls are of paramount interest. We are proposing a framework that will read and interpret the constraints from a natural language and generate data-quality validation rules or code. Data Scientists and engineers spend a considerable time in cleaning the data and we believe the community will greatly benefit from our contribution.

##### Function and Benefits:  
The model will parse through field name description (written in natural language) for given data source and will automatically generate rules and constraint code for the target frameworks. The generated constraint code can validate the records in the source and quantify data quality.
In data governance programs, this tool would certainly help data stewards plug the leakage on incorrect or invalid data. We foresee that this will directly impact data validation, data cleaning and data quality assessment by automating the constraint generation process. (refer : flow-chart-1)   

##### Background:  
Recently the industry has seen an increased focus on data-quality and as per Gartner*, the leaders are of the likes of - Informatica, IBM, SAP, SAS, Oracle, Talend etc.  

They all seem to either auto-generate the constraints from the data or manually define the constraints, but do not derive from the data variable descriptions automatically. As these models are generating the constraints from the data itself and are not leveraging the domain knowledge, they have potential limitations. Our proposal compliments the existing solution space.
This could be used to either benchmark the models from these leaders or be used in conjunction with them to improve overall constraints quality.  

![alt text](./autoValidationCodeGenerator/docs/flowChart.png "Logo Title Text 1")

***

### 2. Software Prerequisites

We used following API / framework:  
0. **Python**
    - **`Version`** - 3.6.* and above  
    - **`Website`** - https://www.python.org/  
1. **Spacy**  
    - **`Overview`** - spaCy is a open source library for advanced Natural Language Processing in Python and Cython.  
    - **`Version`** - 2.2.1  
    - **`Install instruction`** - `pip install spacy`  
    - **`Website`** - https://spacy.io/usage/spacy-101
    - **`Purpose`** - Primarily used for - Tokenization, Dependency Parsing, POS Tagging, Entity Resolution and Rule based matching.
2. **Jinja2**  
    - **`Overview`** - Jinja is a fast, expressive, extensible templating engine. Special placeholders in the template allow writing code similar to Python syntax. Then the template is passed data to render the final document.  
    - **`Version`** - 2.10.3  
    - **`Install instruction`** - `pip install -U Jinja2`  
    - **`Website`** - https://pypi.org/project/Jinja2/  
    - **`Purpose`** - Generating code templates for different target frameworks
3. **Pandas**  
    - **`Overview`** - Pandas is an open source library providing high-performance, easy-to-use data structures and data analysis tools for the Python programming language.  
    - **`Version`** - 0.25.3  
    - **`Install instruction`** - `pip install pandas`  
    - **`Website`** - https://pandas.pydata.org/  
    - **`Purpose`** - Target framework for which constraint code is generated.
4. **rpy2**  
    - **`Overview`** - R is a open source language and environment for statistical computing and graphics. R provides a wide variety of statistical techniques, and is highly extensible  
    - **`Version`** - 3.2.4  
    - **`Install instruction`** - `pip install rpy2`  
    - **`Website`** - https://www.r-project.org/
    - **`Purpose`** - Used in testing for executing auto generated R code in Python
5. **Pytest**  
    - **`Overview`**
    - **`Version`** - 5.3.2
    - **`Install instruction`** - `pip install -U pytest`  
    - **`Website`** - https://docs.pytest.org/en/latest/
    - **`Purpose`** - Unit test library to test auto generated code and validate their functionality

> Note: Anaconda installations may have challenges with rpy2 latest edition. Thus few test cases will skip if proper version of rpy2 (3.2.4 or above) is not installed.

### 3. Software implementation  

##### Modules  
0. **orchestrator.py**
    - **`Purpose`** - As the name suggests this module orchestrates the steps required for the framework to autogenerate the constraint code. "ValidationCodeGenerator" is the only class defined in the module and it exposes a function "generate_code" which is the key usage for users of this framework.
    - **`Key Steps`** -
      - Instantiate ValidationCodeGenerator with a Target framework (Currently supports only Pandas and R)
      - In the constructor we instantiate the Pattern Registry with pre configured patterns (Currently Supports AllEqualsTo and Few Comparators)
      - In generate_code method - Spacy matcher matches the pattern registered in the pattern registry and invokes corresponding pattern code generation logic
    - **`Furture Extension`** - As of now only following constraints have been registered to the framework - AllEqualsTo(Number/String) and Comparators. To extend the functionality to other constraints such as Conditionals, Uniqueness, etc., implement the corresponding constraint class with accepted rules and code generation logic and register the constraint with `Pattern Registry`
    ```Python
    class ValidationCodeGenerator :
      ...
      def __init__ (self, target_framework: TargetFramework) :
        ...
        self._pattern_registry = {
          "allEqualTo": AllEqualTo(),
          "comparator": Comparators(),
          "<<TODO: Custom Constraint>>": "<<TODO: Custom Constraint Class>>" # Must implement rules and generate_code logic
        }
    ```
1. **supported_frameworks.py**
    - **`Purpose`** - Given the ubiquitous usage of dataframe, we have picked the following framework - pandas (python) and R
2. **`constraints\allEqualTo.py`** -
    - **`Purpose`** - Implement the baseline constraint check all column values equals to a literal (number or string)
3. **`constraints\comparators.py`** -
    - **`Purpose`** - Implement the baseline constraint of comparing (equal, greater than , less than etc) two columns in data frame
4. **`templates\pandas\check_all_equal_of.txt`**
    - **`Purpose`** - Jinja template for allEqualsTo in pandas
5. **`templates\pandas\check_comparator.txt`**
    - **`Purpose`** - Jinja template for comparators in pandas
6. **`templates\r\check_all_equal_of.txt`**
    - **`Purpose`** - Jinja template for allEqualsTo in R
7. **`templates\r\check_comparator.txt`**
    - **`Purpose`** - Jinja template for comparators in R
8. **`tests\test_all_equal_to_pandas.py`**
    - **`Purpose`** - Parametrized test cases for allEqualsTo in Pandas. We have validated the autogenerated code as well as its functionality.
9. **`tests\test_all_equal_to_r.py`** -
    - **`Purpose`** - Parametrized test cases for allEqualsTo in R. We have validated the autogenerated code as well as its functionality.
10. **`tests\test_comparators_r.py`**
    - **`Purpose`** - Parametrized test cases for various comparators in R. We have validated the autogenerated code as well as its functionality.

> Note: We have 60 test cases and for proper coverage and usage please check the examples in the test cases.

##### Future extension / any further improvement.
Currently we have implemented limited constraints such as allEqualsTo and various other comparators. In future we envision extension for conditional constraints such as 'if then else' and other complex constraints. Also in this framework we utilized rule based matching in Spacy for good results. We believe that for future complex enhancements we may have to leverage custom statistical models.


##### Limitation
1. We have implemented limited constraints (allEqualsTo and Comparators) in our codebase. Scenarios covered are unit tested extensibly.
2. We have following restrictions - single line descriptions and attribute names appear as column names in data frames.

##### Improvement
1. To extend this software have to implement more constraints
2. To improve robustness of the framework

***

### 4. Usage of the software
> Note: Please take a look at unit test cases for usage and covered scenarios.

```Python
from autoValidationCodeGenerator.orchestrator import TargetFramework
from autoValidationCodeGenerator.orchestrator import ValidationCodeGenerator

def test_generate_code (field_name, field_desc):
  code_gen_instance = ValidationCodeGenerator(TargetFramework.PANDAS)
  constraint_code = code_gen_instance.generate_code(field_name, field_desc)

  print(constraint_code)
  # For Pandas: Use in your environment against the dataframes. Please take a look @ test_all_equal_to_pandas.py .. test_generate_code_allequalto_text and test_generated_code_returns_false_on_invalid_data
  # For R : Use in your environment against the dataframes. Please take a look @ test_all_equal_to_r.py .. test_generate_code_allequalto_text and test_generated_code_returns_false_on_invalid_data

```

***
### 4. Contribution of each team member
***
Name | NetId | Contribution
--- | --- | ---
Sushil Khandelwal  -  `(Team Leader)`| sushilk2 | Proposed frameworks/API's to use in the development, provided guidance in implementation of constraints files, test cases, Coding, writing test cases, helped teams to fix issues/blockers.
Shawn Patel | sjpatel7 | Implemented constraints, test cases, Documentation, help other team member in to fix issues, Final presentation
Pratiksha Misra | pmisra3 | Written test cases, Documentation
Varun Madhavan | madhava1 | Documentation, written test cases
Dhirendra Kumar | dk21 | Worked on code generator template, Documentation, test cases
